# FIR C-vs-RTL Coverage Project: Source Code Index

CS5291 Project 1 - LLM-Based HLS Testbench Generation and Coverage Evaluation.
This package holds every source file written for the project, in two kits:

- `laptop_kit/`  Windows laptop: Vitis HLS 2025.1, xsim coverage, gcov  (D:\hls\kit)
- `server_kit/`  Linux lab server: Synopsys VCS, Cadence JasperGold  (~/server_kit)

The HLS-generated Verilog (`rtl/fir.v`, `rtl/fir_mul_32s_32s_32_2_1.v`) is not
included because it is produced by Vitis: run `run_all.bat`, then copy
`D:\hls\kit\fir_prj_v2\sol1\syn\verilog\*.v` into `server_kit/rtl/`.

---------------------------------------------------------------------------
## 1. Design under test

| File | What it is |
|---|---|
| `fir.cpp` | 8-tap FIR filter (dot product of x[8] and c[8]) with output saturation to +-1000. The HLS top function. No HLS pragmas: Vitis pipelined the loop and shared one 32x32 multiplier on its own (14-cycle latency, 3 DSP, 338 FF, 286 LUT). |

## 2. Testbenches (the "optimisation" of the test stimulus)

The improvement work in this project is on the **tests**, not the hardware:
each testbench is a step up in stimulus quality.

| File | Tests | What it adds | Result |
|---|---|---|---|
| `tb_v0.cpp` | 1 | baseline: one normal input, coefficients all 1 | C: 100% line, 66.7% branch |
| `tb_v1.cpp` | 3 | directed corner cases: saturate high (+1600) and low (-1600) | C: 100% branch; RTL toggle only 43% (xsim) / 50% (VCS) |
| `tb_v2.cpp` | 304 | 8 boundary tests, 93 walking-ones tests (every bit of x and c), 200 fixed-seed random signed tests, independent 64-bit golden model, overflow-safe range (+-16383) | C: 100% branch; RTL toggle 72% (xsim) / 89% (VCS), multiplier 100% |

## 3. Laptop automation (laptop_kit)

| File | What it does |
|---|---|
| `run_all.bat` | One command for everything: puts MSYS2 first on PATH, checks tools, C coverage (g++ --coverage + gcovr) for tb_v0/v1/v2, then for tb_v1 and tb_v2 writes a Tcl script, runs Vitis csim + synthesis + C/RTL co-simulation, checks PASS, re-runs the generated xsim simulation with `-cc_type sbct` coverage and builds the xcrg report |
| `summarize.py` | Parses gcovr JSON, the co-simulation reports and the xcrg `modules.html`, keeps only the DUT rows (fir, fir_mul) and memory models, writes `results\summary.csv` |
| `README.txt` | How to run the kit and what each output is |

## 4. Server RTL flow (server_kit)

| File | What it does |
|---|---|
| `fir_logger.cpp` | Wraps `fir()` so an unchanged C testbench records every call (x, c, expected result) into `vectors_vX.txt`, exactly like Vitis co-simulation records transactions |
| `tb_fir.v` | Simulator-independent Verilog testbench: replays the vectors on the HLS RTL through the ap_ctrl_hs handshake and the two memory ports, checks every result. Options: `+VEC=file`, `+GAP=n` (random 0..n idle cycles between calls), `+RST=n` (every n-th call interrupted by a reset at a random cycle, then re-run) |
| `cm_hier.cfg` | Restricts VCS coverage to the design instance `tb_fir.dut` (excludes the testbench) |
| `run_vcs.sh` | Clears old coverage databases, then for v1 and v2: generates vectors, compiles with `vcs -full64 -cm line+cond+branch+tgl+fsm`, simulates, builds URG reports, prints the coverage tables |
| `run_extra.sh` | Random-gap run (merged into v2), reset-injection run (`simv_rst`), and both JasperGold proofs, with all cleanup steps |
| `README.txt` | How to run the server kit |
| `PROGRESS.md` | Progress log of the server work |

## 5. Formal verification (server_kit)

| File | What it does | Result |
|---|---|---|
| `fir_props.sv` | Proof 1: asserts the two stall signals are never 1; covers the uncovered stall branches, lines 174-175 and line 304; sanity covers for loop exit and ap_done | 2 proven, 3 unreachable, 2 covered (13 and 15 cycles) |
| `jg_run.tcl` | JasperGold script for proof 1 (analyze, elaborate, clock/reset, prove, write summary) | |
| `fir_props2.sv` | Proof 2: line-216 branch, stage-0 enable outside the loop state (lines 191/274/282), redundant check at line 292, line-301 condition rows; two sanity covers | 4 unreachable, 2 covered |
| `jg_run2.tcl` | JasperGold script for proof 2 | |

---------------------------------------------------------------------------
## How to run

Laptop:
    cd /d D:\hls\kit
    run_all.bat
    type results\summary.csv

Server:
    ssh <user>@<server>
    tcsh
    source ~/eda_setup.csh
    cd ~/server_kit
    bash run_vcs.sh
    bash run_extra.sh

## What was improved during the project (beyond the first version)

1. Stimulus: tb_v0 -> tb_v1 -> tb_v2 (directed corner cases, walking ones, random, golden model).
2. New RTL test types in tb_fir.v: random gaps (+GAP) and reset injection (+RST): FSM 60% -> 100%.
3. Coverage restricted to the DUT (cm_hier.cfg, summarize.py), avoiding misleading totals.
4. Formal proofs (fir_props.sv, fir_props2.sv) showing the remaining gap is dead HLS template code.
5. Robustness fixes in the scripts: MSYS2 first on PATH (Windows g++ clash), `vcs -full64`,
   clearing old .vdb databases before a run, deleting jgproject and using `< /dev/null` for JasperGold.

Not done yet: HLS pragma variants (pipeline/unroll/partition) and the LLM-generated testbenches.
