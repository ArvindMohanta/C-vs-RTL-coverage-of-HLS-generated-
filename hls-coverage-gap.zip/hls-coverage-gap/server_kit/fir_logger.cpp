// fir_logger.cpp - records every call the C testbench makes, like Vitis cosim does.
// Compile together with an unchanged testbench:  g++ fir_logger.cpp tb_v2.cpp -o gen
// Writes one line per call: x[0..7] c[0..7] result  (32-bit hex, two's complement)
#include <cstdio>
#include <cstdlib>
#define fir fir_impl
#include "fir.cpp"
#undef fir

int fir(int x[8], int c[8]) {
    static FILE *f = nullptr;
    if (!f) {
        const char *name = getenv("VEC_FILE");
        f = fopen(name ? name : "vectors.txt", "w");
    }
    int r = fir_impl(x, c);
    for (int i = 0; i < 8; i++) fprintf(f, "%08x ", (unsigned)x[i]);
    for (int i = 0; i < 8; i++) fprintf(f, "%08x ", (unsigned)c[i]);
    fprintf(f, "%08x\n", (unsigned)r);
    fflush(f);
    return r;
}
