// tb_fir.v - simulator-independent testbench for the Vitis HLS fir module.
// Replays the transactions recorded from the C testbench (vectors file),
// driving the ap_ctrl_hs handshake and the two ap_memory ports like cosim does.
// Usage: +VEC=vectors_v2.txt   optional: +GAP=<max idle cycles between calls, random>
//        +RST=<n>: every n-th call is first aborted by a reset pulse at a random cycle,
//                  then re-run normally (exercises reset-while-busy FSM transitions)
`timescale 1ns/1ps
module tb_fir;
  reg         clk = 0, rst = 1, start = 0;
  wire        done, idle, ready;
  wire [2:0]  x_addr, c_addr;
  wire        x_ce, c_ce;
  reg  [31:0] x_q, c_q;
  wire [31:0] ret;
  reg  [31:0] xmem [0:7];
  reg  [31:0] cmem [0:7];
  reg  [31:0] v [0:16];
  reg  [1023:0] vecfile;
  integer fd, i, n, tests, errors, gap, maxgap, cycles, rstevery, aborts, wait_c;

  always #5 clk = ~clk;                       // 10 ns clock, as in Vitis

  // ap_memory read ports: 1-cycle read latency (block RAM behaviour)
  always @(posedge clk) begin
    if (x_ce) x_q <= xmem[x_addr];
    if (c_ce) c_q <= cmem[c_addr];
  end

  fir dut (
    .ap_clk(clk), .ap_rst(rst), .ap_start(start),
    .ap_done(done), .ap_idle(idle), .ap_ready(ready),
    .x_address0(x_addr), .x_ce0(x_ce), .x_q0(x_q),
    .c_address0(c_addr), .c_ce0(c_ce), .c_q0(c_q),
    .ap_return(ret));

  always @(posedge clk) if (!rst) cycles = cycles + 1;

  initial begin
    tests = 0; errors = 0; cycles = 0; maxgap = 0; rstevery = 0; aborts = 0;
    if (!$value$plusargs("VEC=%s", vecfile)) vecfile = "vectors.txt";
    if ($value$plusargs("GAP=%d", maxgap)) $display("Random gap between calls: 0..%0d cycles", maxgap);
    if ($value$plusargs("RST=%d", rstevery)) $display("Reset injected during every %0d-th call", rstevery);
    fd = $fopen(vecfile, "r");
    if (fd == 0) begin $display("ERROR: cannot open %0s", vecfile); $finish; end
    repeat (3) @(negedge clk);
    rst = 0;
    @(negedge clk);
    while (!$feof(fd)) begin
      n = 0;
      for (i = 0; i < 17; i = i + 1) n = n + $fscanf(fd, "%h", v[i]);
      if (n == 17) begin
        for (i = 0; i < 8; i = i + 1) begin xmem[i] = v[i]; cmem[i] = v[8 + i]; end
        if (rstevery > 0 && (tests % rstevery) == 0) begin
          // abort this call with a reset at a random point (1..16 cycles after start)
          start = 1;
          wait_c = 1 + ($urandom % 16);
          repeat (wait_c) begin @(negedge clk); if (ready) start = 0; end
          rst = 1; start = 0;
          repeat (2) @(negedge clk);
          rst = 0;
          @(negedge clk);
          aborts = aborts + 1;
        end
        start = 1;
        @(negedge clk);
        while (!done) begin
          if (ready) start = 0;
          @(negedge clk);
        end
        start = 0;
        tests = tests + 1;
        if (ret !== v[16]) begin
          errors = errors + 1;
          $display("FAIL test %0d: got %0d expected %0d", tests, $signed(ret), $signed(v[16]));
        end
        if (maxgap > 0) begin
          gap = $urandom % (maxgap + 1);
          repeat (gap) @(negedge clk);
        end
      end
    end
    $fclose(fd);
    $display("RTL tests = %0d, errors = %0d, cycles = %0d, reset aborts = %0d", tests, errors, cycles, aborts);
    if (errors == 0) $display("*** RTL SIMULATION PASS ***"); else $display("*** RTL SIMULATION FAIL ***");
    $finish;
  end
endmodule
