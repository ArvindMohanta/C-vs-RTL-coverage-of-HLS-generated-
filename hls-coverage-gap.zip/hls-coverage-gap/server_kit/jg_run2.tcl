# jg_run2.tcl - second JasperGold run (remaining branch/condition items)
# Run in ~/server_kit:  jg -batch -tcl jg_run2.tcl |& tee results/jg2.log
clear -all
analyze -sv12 rtl/fir_mul_32s_32s_32_2_1.v rtl/fir.v fir_props2.sv
elaborate -top fir
clock ap_clk
reset ap_rst
prove -all
catch {
  set f [open results/jg_summary2.txt w]
  foreach p [get_property_list] {
    set line "$p : [get_status $p]"
    puts $line
    puts $f $line
  }
  close $f
}
exit -force
