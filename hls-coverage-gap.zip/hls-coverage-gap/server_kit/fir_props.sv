// fir_props.sv - formal properties for the HLS-generated fir module (JasperGold)
// Bound into fir, so the internal signal names below must exist in rtl/fir.v.
//   asserts  -> expected PROVEN      (the stall signals can never be 1)
//   C_dead_* -> expected UNREACHABLE (the code VCS reported as uncovered can never run)
//   C_live_* -> expected COVERED     (sanity checks: normal operation is reachable,
//                                     so the analysis is not vacuous)
module fir_props (
  input logic ap_clk, ap_rst, ap_start, ap_done,
  input logic ap_CS_fsm_state1, ap_CS_fsm_pp0_stage0,
  input logic ap_enable_reg_pp0_iter3, ap_enable_reg_pp0_iter4,
  input logic ap_block_pp0_stage0_subdone, ap_block_pp0_stage0_11001
);
  default clocking cb @(posedge ap_clk); endclocking
  default disable iff (ap_rst);

  // loop-exit condition used in the FSM next-state logic (state pp0_stage0)
  logic exit_cond;
  assign exit_cond = (ap_enable_reg_pp0_iter3 == 1'b0) && (ap_enable_reg_pp0_iter4 == 1'b1)
                     && (ap_block_pp0_stage0_subdone == 1'b0);

  // 1. The pipeline-stall signals are constant 0
  A_subdone_never_1 : assert property (!ap_block_pp0_stage0_subdone);
  A_11001_never_1   : assert property (!ap_block_pp0_stage0_11001);

  // 2. Code reported uncovered by VCS
  // else-branches of the stage enables (lines 139, 149, 159, 169): need a stall
  C_dead_stall_branches : cover property (ap_block_pp0_stage0_subdone);
  // statements 174-175: stall AND a new start while idle
  C_dead_line174 : cover property (ap_block_pp0_stage0_subdone && ap_start && ap_CS_fsm_state1);
  // line 304: final else after "if (!exit_cond) ... else if (exit_cond) ..."
  C_dead_line304 : cover property (ap_CS_fsm_pp0_stage0 && !(!exit_cond) && !exit_cond);

  // 3. Sanity: normal behaviour must be reachable
  C_live_loop_exit : cover property (ap_CS_fsm_pp0_stage0 && exit_cond);
  C_live_done      : cover property (ap_done);
endmodule

bind fir fir_props u_props (.*);
