// fir_props2.sv - second set of JasperGold properties for the HLS fir module.
// Settles the remaining uncovered branch and condition items reported by VCS.
//   C2_dead_* -> expected UNREACHABLE      C2_live_* -> expected COVERED (sanity)
module fir_props2 (
  input logic       ap_clk, ap_rst, ap_start,
  input logic [3:0] ap_CS_fsm,
  input logic       ap_CS_fsm_state1, ap_CS_fsm_pp0_stage0,
  input logic       ap_enable_reg_pp0_iter0, ap_enable_reg_pp0_iter3, ap_enable_reg_pp0_iter4,
  input logic       ap_block_pp0_stage0_subdone, ap_block_pp0_stage0_11001
);
  default clocking cb @(posedge ap_clk); endclocking
  default disable iff (ap_rst);

  logic exit_cond;   // condition used at lines 299 and 301
  assign exit_cond = (ap_enable_reg_pp0_iter3 == 1'b0) && (ap_enable_reg_pp0_iter4 == 1'b1)
                     && (ap_block_pp0_stage0_subdone == 1'b0);

  // Branch at line 216: implicit else needs ap_block_pp0_stage0_11001 = 1
  C2_dead_line216_else : cover property (ap_block_pp0_stage0_11001);

  // Lines 191, 274, 282, row "1 1 0": stage-0 enable set while FSM is not in the loop state
  C2_dead_iter0_outside_loop : cover property (ap_enable_reg_pp0_iter0 && !ap_CS_fsm_pp0_stage0);

  // Line 292, row "1 0": inside "case state1" (ap_CS_fsm == state1 encoding 4'd1),
  // ap_CS_fsm_state1 would have to be 0
  C2_dead_line292_redundant : cover property ((ap_CS_fsm == 4'd1) && !ap_CS_fsm_state1);

  // Line 301, rows 011/101/110: the else-if is evaluated only when line 299's
  // "if (~exit_cond)" is false, i.e. exit_cond is true; then no part can be false
  C2_dead_line301_partial : cover property (ap_CS_fsm_pp0_stage0 && exit_cond &&
        ((ap_enable_reg_pp0_iter3 != 1'b0) || (ap_enable_reg_pp0_iter4 != 1'b1)
         || (ap_block_pp0_stage0_subdone != 1'b0)));

  // Sanity: the normal versions of the same situations are reachable
  C2_live_iter0_in_loop : cover property (ap_enable_reg_pp0_iter0 && ap_CS_fsm_pp0_stage0);
  C2_live_start_in_idle : cover property (ap_start && ap_CS_fsm_state1);
endmodule

bind fir fir_props2 u_props2 (.*);
