Server kit: RTL coverage of the HLS fir module with Synopsys VCS (and later Xcelium/JasperGold)

Files
  fir.cpp, tb_v1.cpp, tb_v2.cpp  same design and testbenches as the Windows kit
  fir_logger.cpp                 records every fir() call of a C testbench into vectors_vX.txt
  tb_fir.v                       Verilog testbench that replays the vectors on the RTL
  cm_hier.cfg                    restricts coverage to the design (tb_fir.dut) only
  run_vcs.sh                     runs everything for v1 and v2
  rtl/                           copy here: fir.v and fir_mul_32s_32s_32_2_1.v
                                 (from D:\hls\kit\fir_prj_v2\sol1\syn\verilog on the laptop)
Run (on the server)
  tcsh
  source ~/eda_setup.csh
  cd ~/server_kit
  bash run_vcs.sh
Option: random idle gaps between calls (exercises idle/start control paths)
  ./simv_v2 -cm line+cond+branch+tgl+fsm +VEC=vectors_v2.txt +GAP=5 -no_save
