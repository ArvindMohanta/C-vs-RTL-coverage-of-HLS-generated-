#!/bin/bash
# run_vcs.sh - RTL coverage of the HLS-generated fir module with Synopsys VCS
# Run from tcsh after:  source ~/eda_setup.csh      then:  bash run_vcs.sh
# Needs: rtl/ folder with fir.v and fir_mul_32s_32s_32_2_1.v (from Vitis syn/verilog)
set -e
cd "$(dirname "$0")"
mkdir -p results
# remove old coverage databases: VCS/URG would otherwise merge earlier runs into the new report
rm -rf simv_v1.vdb simv_v2.vdb
METRICS=line+cond+branch+tgl+fsm
[ -f rtl/fir.v ] || { echo "ERROR: rtl/fir.v not found. Copy the Vitis syn/verilog files into rtl/"; exit 1; }

for V in v1 v2; do
  echo "=== $V: generating vectors from tb_$V.cpp ==="
  g++ -O0 fir_logger.cpp tb_$V.cpp -o gen_$V
  VEC_FILE=vectors_$V.txt ./gen_$V | tee results/${V}_c_run.txt
  echo "    $(wc -l < vectors_$V.txt) transactions recorded"

  echo "=== $V: VCS compile with coverage ==="
  vcs -full64 -sverilog -timescale=1ns/1ps -cm $METRICS -cm_hier cm_hier.cfg \
      tb_fir.v rtl/*.v -o simv_$V -l results/${V}_vcs_compile.log > /dev/null

  echo "=== $V: VCS simulation ==="
  ./simv_$V -cm $METRICS +VEC=vectors_$V.txt -no_save -l results/${V}_vcs_sim.log | grep -E "RTL tests|PASS|FAIL"

  echo "=== $V: URG coverage report ==="
  rm -rf results/urg_$V
  urg -full64 -dir simv_$V.vdb -report results/urg_$V -format both > results/${V}_urg.log 2>&1
  echo "    report: results/urg_$V/dashboard.html (text: results/urg_$V/hierarchy.txt)"
done

echo
echo "=== Coverage per module (v1 then v2) ==="
for V in v1 v2; do
  echo "--- $V ---"
  cat results/urg_$V/hierarchy.txt
done
