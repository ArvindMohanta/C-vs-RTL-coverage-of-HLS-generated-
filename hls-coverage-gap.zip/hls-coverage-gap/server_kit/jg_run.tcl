# jg_run.tcl - JasperGold: prove the uncovered HLS logic is unreachable
# Run in ~/server_kit:  jg -batch -tcl jg_run.tcl |& tee results/jg.log
clear -all
analyze -sv12 rtl/fir_mul_32s_32s_32_2_1.v rtl/fir.v fir_props.sv
elaborate -top fir
clock ap_clk
reset ap_rst
prove -all
# one line per property: name and result
catch {
  set f [open results/jg_summary.txt w]
  foreach p [get_property_list] {
    set line "$p : [get_status $p]"
    puts $line
    puts $f $line
  }
  close $f
}
exit -force
