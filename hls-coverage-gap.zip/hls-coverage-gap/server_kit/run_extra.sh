#!/bin/bash
# run_extra.sh - reproduces the extra server experiments after run_vcs.sh:
#   random idle gaps (merged into simv_v2.vdb), reset injection (simv_rst), JasperGold
# Run from tcsh after:  source ~/eda_setup.csh   then:  bash run_extra.sh
set -e
cd "$(dirname "$0")"
M=line+cond+branch+tgl+fsm
[ -x simv_v2 ] || { echo "Run bash run_vcs.sh first"; exit 1; }

echo "=== v2 + random gaps (0..5 cycles) ==="
./simv_v2 -cm $M +VEC=vectors_v2.txt +GAP=5 -no_save -cm_name gap5 -l results/gap_sim.log | grep -E "RTL tests|PASS|FAIL"
urg -full64 -dir simv_v2.vdb -report results/urg_v2_gap -format text > results/gap_urg.log 2>&1

echo "=== reset injection (every 3rd call) ==="
rm -rf simv_rst.vdb
vcs -full64 -sverilog -timescale=1ns/1ps -cm $M -cm_hier cm_hier.cfg tb_fir.v rtl/*.v \
    -o simv_rst -l results/rst_compile.log > /dev/null
./simv_rst -cm $M +VEC=vectors_v2.txt -no_save -cm_name normal -l results/rst_sim_normal.log | grep -E "RTL tests|PASS|FAIL"
./simv_rst -cm $M +VEC=vectors_v2.txt +RST=3 -no_save -cm_name rst3 -l results/rst_sim_rst3.log | grep -E "RTL tests|PASS|FAIL"
rm -rf results/urg_rst
urg -full64 -dir simv_rst.vdb -report results/urg_rst -format text > results/rst_urg.log 2>&1

echo "=== JasperGold (proof 1) ==="
rm -rf jgproject
jg -batch -tcl jg_run.tcl < /dev/null > results/jg.log 2>&1 || true
cat results/jg_summary.txt

echo "=== JasperGold (proof 2) ==="
rm -rf jgproject
jg -batch -tcl jg_run2.tcl < /dev/null > results/jg2.log 2>&1 || true
cat results/jg_summary2.txt

echo
for R in urg_v2_gap urg_rst; do echo "--- $R ---"; cat results/$R/hierarchy.txt; done
grep -A8 "^transitions" results/urg_rst/modinfo.txt
