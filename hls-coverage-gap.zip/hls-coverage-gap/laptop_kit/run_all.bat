@echo off
REM ======================================================================
REM run_all.bat - reproduces every result in the progress-meeting deck
REM   C coverage (gcov) for tb_v0, tb_v1, tb_v2
REM   Vitis HLS csim + synthesis + C/RTL cosim for tb_v1 and tb_v2
REM   RTL statement/branch/condition/toggle coverage (xsim + xcrg)
REM   results\summary.csv with all numbers
REM Usage: put this folder anywhere (e.g. D:\hls\kit), open Command Prompt:
REM        cd /d D:\hls\kit
REM        run_all.bat
REM ======================================================================
setlocal EnableExtensions

REM ---- edit these if your install paths differ ----
set "VITIS_SETTINGS=D:\Xilinx\2025.1\Vitis\settings64.bat"
set "VIVADO_BIN=D:\Xilinx\2025.1\Vivado\bin"
set "MSYS_BIN=D:\msys64\ucrt64\bin"
set "PART=xc7z020clg400-1"
set "CLOCK=10"
REM -------------------------------------------------

set "ROOT=%~dp0"
cd /d "%ROOT%"
if not exist results mkdir results

echo [1/4] Checking tools...
REM MSYS2 must come first on PATH, otherwise g++ picks up an old DLL from Vitis
set "PATH=%MSYS_BIN%;%PATH%"
where g++ >nul 2>&1 || (echo ERROR: g++ not found in %MSYS_BIN% & goto fail)
where gcovr >nul 2>&1 || (echo ERROR: gcovr not found. Run: python -m pip install gcovr & goto fail)
set "PYEXE="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE set "PYEXE=%%P"
if not defined PYEXE (echo ERROR: python not found & goto fail)
if not exist "%VITIS_SETTINGS%" (echo ERROR: %VITIS_SETTINGS% not found & goto fail)
for %%F in (fir.cpp tb_v0.cpp tb_v1.cpp tb_v2.cpp summarize.py) do if not exist %%F (echo ERROR: %%F missing & goto fail)

echo [2/4] C-level coverage with gcov/gcovr...
call :ccov tb_v0 || goto fail
call :ccov tb_v1 || goto fail
call :ccov tb_v2 || goto fail

echo [3/4] Vitis HLS + co-simulation + RTL coverage (takes several minutes)...
call "%VITIS_SETTINGS%" >nul
cd /d "%ROOT%"
call :hls v1 tb_v1 || goto fail
call :hls v2 tb_v2 || goto fail

echo [4/4] Summary...
cd /d "%ROOT%"
"%PYEXE%" summarize.py
echo.
echo All done. Results are in %ROOT%results
echo   summary.csv            all numbers in one table (open in Excel)
echo   tb_v*_html\index.html  C coverage reports
echo   v*_cosim.rpt           co-simulation reports
echo   RTL reports:           fir_prj_v1 / fir_prj_v2 \sol1\sim\verilog\cov_report\codeCoverageReport\modules.html
start "" "%ROOT%fir_prj_v1\sol1\sim\verilog\cov_report\codeCoverageReport\modules.html"
start "" "%ROOT%fir_prj_v2\sol1\sim\verilog\cov_report\codeCoverageReport\modules.html"
goto :eof

REM ---------------------------------------------------------------- C coverage
:ccov
echo   - %1.cpp
del /q *.gcda *.gcno 2>nul
g++ --coverage -O0 fir.cpp %1.cpp -o %1.exe || (echo ERROR: compile failed for %1 & exit /b 1)
%1.exe > results\%1_c_run.txt
type results\%1_c_run.txt
gcovr -r . --filter fir.cpp > results\%1_c_line.txt
gcovr -r . --filter fir.cpp --txt-metric branch > results\%1_c_branch.txt
type results\%1_c_branch.txt | findstr /b "fir.cpp"
gcovr -r . --filter fir.cpp --json-summary results\%1_c_summary.json
if not exist results\%1_html mkdir results\%1_html
gcovr -r . --filter fir.cpp --html-details results\%1_html\index.html
exit /b 0

REM ------------------------------------------------- HLS + cosim + RTL coverage
:hls
set "PRJ=fir_prj_%1"
echo   - %PRJ% with %2.cpp
if exist %PRJ% rmdir /s /q %PRJ%
(
echo open_project %PRJ%
echo set_top fir
echo add_files fir.cpp
echo add_files -tb %2.cpp
echo open_solution sol1 -flow_target vivado
echo set_part %PART%
echo create_clock -period %CLOCK%
echo csim_design
echo csynth_design
echo cosim_design -rtl verilog
echo exit
) > run_%1.tcl
call vitis-run --mode hls --tcl run_%1.tcl > results\%1_hls_log.txt 2>&1
findstr /c:"co-simulation finished: PASS" results\%1_hls_log.txt >nul || (echo ERROR: cosim did not PASS, see results\%1_hls_log.txt & exit /b 1)
echo     cosim PASS
copy /y %PRJ%\sol1\sim\report\fir_cosim.rpt results\%1_cosim.rpt >nul
copy /y %PRJ%\sol1\syn\report\fir_csynth.rpt results\%1_csynth.rpt >nul
pushd %PRJ%\sol1\sim\verilog
powershell -NoProfile -Command "(Get-Content run_xsim.bat) -replace ' -s fir', ' -cc_type sbct -cc_db fir_cov -cc_dir ./cov -s fir' | Set-Content run_xsim_cov.bat"
cmd /c run_xsim_cov.bat > "%ROOT%results\%1_xsim_cov_log.txt" 2>&1
call "%VIVADO_BIN%\xcrg" -cc_db fir_cov -cc_dir ./cov -cc_report ./cov_report > "%ROOT%results\%1_xcrg_log.txt" 2>&1
popd
if not exist %PRJ%\sol1\sim\verilog\cov_report\codeCoverageReport\modules.html (echo ERROR: no RTL coverage report for %1 & exit /b 1)
echo     RTL coverage report created
exit /b 0

:fail
echo.
echo *** Stopped because of the error above. ***
exit /b 1
