// tb_v2.cpp - improved self-checking testbench for fir()
// Goal: keep 100% C coverage AND raise RTL toggle/branch coverage by
// exercising the full bit range of BOTH inputs (x and c), not just c = 1.
//
// Test groups:
//   1. Directed   : original normal / saturate-high / saturate-low cases
//   2. Boundaries : zeros, exact thresholds (+-1000, +-1001), sign mixes
//   3. Walking 1s : one bit set at a time in x and in c (bits 0..30)
//   4. Random     : NUM_RANDOM vectors, values in [-16383, 16383], fixed seed
//
// Value ranges are chosen so the 8-tap sum never overflows a 32-bit int
// (8 * 16383^2 < 2^31), so C behaviour is well defined and matches RTL.
// Negative values make the upper bits (incl. sign bit 31) toggle.

#include <cstdio>

int fir(int x[8], int c[8]);

static const int NUM_RANDOM = 200;     // change for experiments
static unsigned int lcg_state = 12345; // fixed seed -> reproducible tests

// Portable pseudo-random generator (Windows rand() only gives 15 bits)
static unsigned int lcg_next() {
    lcg_state = lcg_state * 1664525u + 1013904223u;
    return lcg_state;
}
static int rand_range(int lo, int hi) {           // inclusive
    return lo + (int)(lcg_next() % (unsigned)(hi - lo + 1));
}

// Independent golden reference model (64-bit accumulation)
static int golden(const int x[8], const int c[8]) {
    long long acc = 0;
    for (int i = 0; i < 8; i++) acc += (long long)x[i] * c[i];
    if (acc > 1000)  acc = 1000;
    if (acc < -1000) acc = -1000;
    return (int)acc;
}

static int tests = 0, errors = 0;

static void run(int x[8], int c[8], const char *name) {
    int exp = golden(x, c);
    int got = fir(x, c);
    tests++;
    if (got != exp) {
        errors++;
        printf("FAIL [%s] test %d: got %d expected %d\n", name, tests, got, exp);
    }
}

static void fill(int a[8], int v) { for (int i = 0; i < 8; i++) a[i] = v; }

int main() {
    int x[8], c[8];

    // 1. Directed tests (same as tb v1)
    for (int i = 0; i < 8; i++) { x[i] = i + 1; c[i] = 1; }
    run(x, c, "normal");
    fill(x, 200);  fill(c, 1); run(x, c, "sat_high");
    fill(x, -200); fill(c, 1); run(x, c, "sat_low");

    // 2. Boundary tests
    fill(x, 0); fill(c, 0);           run(x, c, "all_zero");
    fill(x, 0); x[0] = 1000; c[0] = 1; run(x, c, "eq_+1000");
    x[0] = 1001;                       run(x, c, "eq_+1001");
    x[0] = -1000;                      run(x, c, "eq_-1000");
    x[0] = -1001;                      run(x, c, "eq_-1001");
    fill(x, 16383);  fill(c, -16383);  run(x, c, "max_neg");
    fill(x, -16383); fill(c, -16383);  run(x, c, "neg_neg");
    fill(x, -1);     fill(c, -1);      run(x, c, "all_ones");

    // 3. Walking ones: one bit at a time on x, then on c (single tap active)
    for (int b = 0; b <= 30; b++) {
        int tap = b % 8;
        fill(x, 0); fill(c, 0);
        x[tap] = 1 << b; c[tap] = 1;   run(x, c, "walk_x");
        fill(x, 0); fill(c, 0);
        x[tap] = 1; c[tap] = 1 << b;   run(x, c, "walk_c");
        x[tap] = -1;                   run(x, c, "walk_c_neg");
    }

    // 4. Random tests over the full safe range, both signs
    for (int t = 0; t < NUM_RANDOM; t++) {
        for (int i = 0; i < 8; i++) {
            x[i] = rand_range(-16383, 16383);
            c[i] = rand_range(-16383, 16383);
        }
        run(x, c, "random");
    }

    printf("tests = %d, errors = %d\n", tests, errors);
    return errors ? 1 : 0;   // non-zero makes csim/cosim FAIL
}
