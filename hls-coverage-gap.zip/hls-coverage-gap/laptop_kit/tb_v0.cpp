// tb_v0.cpp - one normal test only (shows 100% line but 66% branch coverage)
#include <cstdio>
int fir(int x[8], int c[8]);
int main() {
    int x[8] = {1,2,3,4,5,6,7,8}, c[8] = {1,1,1,1,1,1,1,1};
    int r = fir(x, c);
    printf("result = %d\n", r);
    return (r == 36) ? 0 : 1;   // self-check against expected value
}
