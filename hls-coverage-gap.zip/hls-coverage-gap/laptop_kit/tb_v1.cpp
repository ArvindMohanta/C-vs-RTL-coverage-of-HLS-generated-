// tb_v1.cpp - 3 directed tests: normal, saturate high, saturate low
// (100% C line and branch coverage; coefficients are always 1)
#include <cstdio>
int fir(int x[8], int c[8]);
int main() {
    int c[8] = {1,1,1,1,1,1,1,1};
    int a[8] = {1,2,3,4,5,6,7,8};
    int b[8], d[8];
    for (int i = 0; i < 8; i++) { b[i] = 200; d[i] = -200; }
    int errors = 0;
    if (fir(a, c) != 36)    errors++;   // normal case
    if (fir(b, c) != 1000)  errors++;   // saturate high
    if (fir(d, c) != -1000) errors++;   // saturate low
    printf("errors = %d\n", errors);
    return errors;
}
