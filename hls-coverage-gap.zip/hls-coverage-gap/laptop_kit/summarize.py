"""summarize.py - collect all results of run_all.bat into results/summary.csv

Reads:
  results/<tb>_c_summary.json            (gcovr --json-summary)
  results/<v>_cosim.rpt                  (Vitis HLS co-simulation report)
  fir_prj_<v>/sol1/sim/verilog/cov_report/codeCoverageReport/modules.html (xcrg)
"""
import csv, glob, json, os, re
from html.parser import HTMLParser

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "results")
DUT = ["fir", "fir_mul", "AESL_automem_x", "AESL_automem_c"]  # rows to report


class TableRows(HTMLParser):
    """Collect the text of every <td>/<th> cell, row by row."""
    def __init__(self):
        super().__init__(); self.rows = []; self.row = None; self.cell = None
    def handle_starttag(self, tag, attrs):
        if tag == "tr": self.row = []
        elif tag in ("td", "th") and self.row is not None: self.cell = ""
    def handle_endtag(self, tag):
        if tag in ("td", "th") and self.row is not None and self.cell is not None:
            self.row.append(" ".join(self.cell.split())); self.cell = None
        elif tag == "tr" and self.row is not None:
            if self.row: self.rows.append(self.row)
            self.row = None
    def handle_data(self, data):
        if self.cell is not None: self.cell += data


def rtl_rows(version):
    path = os.path.join(ROOT, f"fir_prj_{version}", "sol1", "sim", "verilog",
                        "cov_report", "codeCoverageReport", "modules.html")
    if not os.path.exists(path):
        print(f"  (no RTL report for {version}: {path})"); return {}
    p = TableRows(); p.feed(open(path, encoding="utf-8", errors="ignore").read())
    out = {}
    for r in p.rows:
        # module table rows: ID, name, count, hierarchy, stmt, branch, cond, toggle, file, file id
        if len(r) >= 8 and r[0].isdigit():
            name = r[1]
            for key in DUT:
                hit = (name == key) if key == "fir" else name.startswith(key)
                if hit and key not in out:
                    out[key] = {"module": name, "statement": r[4], "branch": r[5],
                                "condition": r[6], "toggle": r[7]}
    return out


def cosim(version):
    path = os.path.join(RES, f"{version}_cosim.rpt")
    if not os.path.exists(path): return {}
    for line in open(path, errors="ignore"):
        cells = [c.strip() for c in line.split("|")]
        if len(cells) > 9 and cells[1] == "Verilog":
            return {"status": cells[2], "latency": cells[4], "interval": cells[7], "total_cycles": cells[9]}
    return {}


def c_cov(tb):
    path = os.path.join(RES, f"{tb}_c_summary.json")
    if not os.path.exists(path): return {}
    d = json.load(open(path))
    run = open(os.path.join(RES, f"{tb}_c_run.txt"), errors="ignore").read().strip()
    return {"line": d.get("line_percent"), "branch": d.get("branch_percent"), "run": run}


rows = []
for tb in ["tb_v0", "tb_v1", "tb_v2"]:
    c = c_cov(tb)
    if c:
        rows.append(["C (gcov)", tb, "fir.cpp", c["line"], c["branch"], "", "", c["run"]])
for v in ["v1", "v2"]:
    co = cosim(v)
    if co:
        rows.append(["Cosim", f"tb_{v}", "fir", "", "", "", "",
                     f"{co['status']}, latency {co['latency']}, interval {co['interval']}, total {co['total_cycles']} cycles"])
    for key, r in rtl_rows(v).items():
        rows.append(["RTL (xcrg)", f"tb_{v}", r["module"], r["statement"], r["branch"], r["condition"], r["toggle"],
                     "DUT" if key in ("fir", "fir_mul") else "generated TB memory model"])

head = ["level", "testbench", "module", "statement_or_line_%", "branch_%", "condition_%", "toggle_%", "note"]
os.makedirs(RES, exist_ok=True)
with open(os.path.join(RES, "summary.csv"), "w", newline="") as f:
    csv.writer(f).writerows([head] + rows)

w = [10, 9, 24, 9, 8, 9, 8]
print("\n" + " ".join(h[:n].ljust(n) for h, n in zip(["level", "tb", "module", "stmt/line", "branch", "cond", "toggle"], w)))
for r in rows:
    print(" ".join(str(x)[:n].ljust(n) for x, n in zip(r, w)), "", r[7])
print(f"\nSaved {os.path.join(RES, 'summary.csv')}")
