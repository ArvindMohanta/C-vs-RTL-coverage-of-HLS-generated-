int fir(int x[8], int c[8]) {
    int acc = 0;
    for (int i = 0; i < 8; i++) acc += x[i] * c[i];
    if (acc > 1000)  acc = 1000;    // saturate high
    if (acc < -1000) acc = -1000;   // saturate low
    return acc;
}
