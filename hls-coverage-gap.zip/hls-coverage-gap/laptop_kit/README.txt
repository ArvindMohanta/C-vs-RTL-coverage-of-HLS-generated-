HLS C-vs-RTL coverage kit (FIR kernel) - reproduces all results in the deck

Requirements (Windows): Vitis 2025.1 in D:\Xilinx, MSYS2 gcc in D:\msys64,
Python 3 with gcovr (python -m pip install gcovr). Edit the paths at the top
of run_all.bat if yours differ.

Files
  fir.cpp       8-tap FIR kernel with saturation (HLS top function: fir)
  tb_v0.cpp     1 normal test        -> C: 100% line, 66.7% branch
  tb_v1.cpp     3 directed tests     -> C: 100% line, 100% branch
  tb_v2.cpp     304 tests (boundary, walking-ones, 200 random, golden model)
  run_all.bat   runs everything below
  summarize.py  collects all numbers into results\summary.csv

Run
  1. Copy this folder to e.g. D:\hls\kit
  2. Open a NEW Command Prompt (do not run settings64.bat yourself)
  3. cd /d D:\hls\kit
  4. run_all.bat

What it does
  [2/4] C coverage for tb_v0, tb_v1, tb_v2 (gcov/gcovr, text + HTML + JSON)
  [3/4] For tb_v1 and tb_v2: Vitis HLS csim, synthesis, C/RTL cosim,
        then re-runs the generated xsim simulation with coverage
        (statement, branch, condition, toggle) and builds the xcrg report
  [4/4] Prints a summary table and writes results\summary.csv

Outputs (results\)
  summary.csv                 every number used in the slides
  tb_v*_c_run.txt / _branch   C test output and gcovr reports
  tb_v*_html\index.html       C coverage HTML
  v*_cosim.rpt, v*_csynth.rpt co-simulation and synthesis reports
  v*_hls_log.txt              full Vitis log (check here if something fails)
RTL reports: fir_prj_v1 and fir_prj_v2\sol1\sim\verilog\cov_report\codeCoverageReport\modules.html
Compare the rows "fir" and "fir_mul_..." (the DUT). Other rows are the generated testbench.

Expected: C coverage is 100% branch for both v1 and v2, but RTL toggle on fir is
about 43% (v1) vs 72% (v2), while RTL branch/condition do not change.
