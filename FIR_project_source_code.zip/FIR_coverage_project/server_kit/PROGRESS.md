# Project 1: LLM-Based HLS Testbench Generation and Coverage Evaluation
## Progress log, lab server part (as of 20 Oct 2026)

Server: bhawani (172.16.82.68), account c_karfa, folder /storage/c_karfa/server_kit
Nodes 172.16.82.69 (avanti), .68 (bhawani), .57, .70 share /storage.

---------------------------------------------------------------------------
## 1. One-time setup (already done)

Tools found:
  Vitis / Vivado 2023.2      module load vivado   (/storage/Xilinx_bhawani)
  Synopsys VCS U-2023.03     + URG, Verdi U-2023.03-SP1  (/home/Synopsys_tools)
  Cadence Xcelium 22.09      xrun  (/home/Cadence_tools/XCELIUM2209)
  Cadence JasperGold 2023.03p002  jg  (/home/Cadence_tools/jasper_2023.03p002)

Setup file ~/eda_setup.csh (3 lines):
  source /storage/common_cadence/synopsys_cshrc
  source /storage/common_cadence/cad_cshrc
  set path = ( /home/Cadence_tools/jasper_2023.03p002/bin $path )

Every login:
  ssh c_karfa@172.16.82.68
  tcsh                       (the setup scripts are C-shell scripts)
  source ~/eda_setup.csh
  cd ~/server_kit

Lessons learned:
  - Always run VCS with -full64. Without it the 32-bit vcs1 fails with
    "libelf.so.1: cannot open shared object file" (only the 64-bit lib is installed).
  - Do not answer y to "Install package python3-vcstool" (unrelated tool).
  - In tcsh use single quotes for patterns containing $ (e.g. grep -v '^ *$').
  - Copy from laptop with:  scp -O <file> c_karfa@172.16.82.68:/storage/c_karfa/server_kit/
    (-O and the full path are needed with the Windows scp)

---------------------------------------------------------------------------
## 2. Files in server_kit

  fir.cpp            8-tap FIR with saturation (HLS top function)
  tb_v1.cpp          3 directed tests (100% C line + branch, coefficients all 1)
  tb_v2.cpp          304 tests (boundary, walking ones, 200 random, golden model)
  fir_logger.cpp     records every fir() call -> vectors_vX.txt (like Vitis cosim)
  tb_fir.v           Verilog testbench replaying the vectors on the RTL
                     options: +VEC=file  +GAP=n (random idle gaps)  +RST=n (reset injection)
  cm_hier.cfg        restricts coverage to tb_fir.dut
  rtl/               fir.v, fir_mul_32s_32s_32_2_1.v (Vitis 2025.1 output from the laptop)
  run_vcs.sh         v1 + v2: vectors, VCS compile/sim with coverage, URG reports
  run_extra.sh       random-gap run, reset-injection run, JasperGold proofs
  fir_props.sv       JasperGold properties (bound into fir)
  jg_run.tcl         JasperGold script
  results/           all logs and reports

---------------------------------------------------------------------------
## 3. Results so far

### 3.1 VCS RTL coverage of the fir module (%, tb_fir.dut incl. multiplier)

| Metric            | v1: 3 tests | v2: 304 tests | v2 + gaps | v2 + reset injection |
|-------------------|-------------|---------------|-----------|----------------------|
| Line              | 96.94       | 96.94         | 96.94     | 96.94                |
| Branch            | 87.69       | 87.69         | 87.69     | 87.69                |
| Condition         | 76.22       | 76.22         | 76.76     | 77.30                |
| FSM               | 60.00       | 60.00         | 60.00     | 100.00               |
| Toggle            | 50.31       | 89.22         | 89.45     | 89.60                |
| Multiplier toggle | 46.32       | 99.08         | 99.08     | 99.39                |

Runs: v1 3 tests 45 cycles; v2 304 tests 4560 cycles; gaps 5056 cycles;
reset run 5438 cycles with 102 reset-aborted calls. All 0 errors.
(Vitis cosim on laptop: 44 and 4559 cycles -> testbench timing matches.)
Gap and reset columns are merged with the v2 run (simv_v2.vdb, simv_rst.vdb).

### 3.2 HLS FSM (ap_CS_fsm): 4 states, 5 transitions
  states: state1 (idle), pp0_stage0 (pipelined loop), state7, state8 (drain)
  v1/v2: all states covered, 3/5 transitions (60%)
  missing: pp0_stage0->state1, state7->state1 = reset during a computation
  reset injection (+RST=3): 5/5 transitions (100%)

### 3.3 Uncovered statements in fir.v (VCS)
  lines 174-175  else if (ap_start & state1) ap_enable_reg_pp0_iter4 <= 0;  (stall path)
  line 304       final else of FSM next-state logic (if ~A / else if A / else)
  stall signals: assign ap_block_pp0_stage0_subdone = ~(1'b1 == 1'b1);  (line 337)
                 assign ap_block_pp0_stage0_11001   = ~(1'b1 == 1'b1);  (line 335)

### 3.4 JasperGold 2023.03p002 (jg -batch -tcl jg_run.tcl)
| Property                | Result                | Meaning                          |
|-------------------------|-----------------------|----------------------------------|
| A_subdone_never_1       | proven                | stall signal never 1             |
| A_11001_never_1         | proven                | stall signal never 1             |
| C_dead_stall_branches   | unreachable           | branches 139-169 dead            |
| C_dead_line174          | unreachable           | statements 174-175 dead          |
| C_dead_line304          | unreachable           | line 304 dead                    |
| C_live_loop_exit        | covered (13 cycles)   | sanity: loop exit reachable      |
| C_live_done             | covered (15 cycles)   | sanity: ap_done reachable        |
Note: Jasper black-boxed the 32x32 multiplier (over-approximation, so the
unreachability proofs remain valid for the real design).
Corrected line coverage (proven-dead lines excluded): 93/93 = 100%.

### 3.5 Uncovered conditions (results/urg_rst/modinfo.txt), classification
  142,152,162,172,183,191,197,203,282,299: rows needing a stall signal = 1 -> dead (proven)
  174 (all rows): expression only evaluated during a stall -> dead (proven)
  301 rows 011/101/110: evaluated only when line 299's ~A is false -> dead by logic
  292 row 10 (start=1, state1=0): redundant check inside the state1 case -> dead by logic
  191/282 row 110 (stage-0 enable outside the loop state): probably dead, to prove
  349 (loop counter i1_fu_46 == 7 combinations): to check

### 3.6 Conclusion so far: three kinds of RTL coverage gap
  1. Data gaps (toggle)         -> closed by better test values (v1 -> v2)
  2. Control scenarios (FSM)    -> closed by a new test type (reset injection)
  3. Dead HLS template code     -> unreachable, proven by JasperGold, exclude

---------------------------------------------------------------------------
## 4. Next steps
  [ ] Branch detail for fir (awk command below) and line 349 of fir.v
  [ ] Second Jasper property file: lines 191/282, 292, 301, 349
  [ ] Corrected branch and condition coverage with exclusions
  [ ] LLM part: manual vs random vs LLM basic vs LLM corner-case testbenches
  [ ] More MachSuite kernels, pragma variants, mutation testing

Pending commands:
  awk '/Branch Coverage for Module : fir/{on=1} /Coverage for Module : fir_mul/{on=0} on' results/urg_rst/modinfo.txt | grep -v '^ *$' | head -80
  sed -n '343,352p' rtl/fir.v
  grep -n "ap_enable_reg_pp0_iter0 <=\|ap_enable_reg_pp0_iter0 =" rtl/fir.v

Laptop side (Windows, D:\hls): Vitis 2025.1, xsim coverage, kit in D:\hls\kit
(run_all.bat), report VLSI_Project_Report.docx, FIR_Coverage_Results.xlsx, slide deck.
